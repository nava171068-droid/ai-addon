# Addon AI
Cursor-style app for Minecraft Bedrock addons. Chat with AI, edit BP/RP files, pack .mcaddon.
- App code: www/index.html (AI provider is the `providers` object, swap in your own model later)
- jszip is copied into www/ by `npm run build`
- Paste your API key in Settings inside the app (stored on device only)

v0.2: attach/import files (zip, mcaddon, images, text), web search + fetch_url tools, addon scaffold, share/export via native sheet.
v0.3: multi-provider (Claude, OpenAI, Gemini, Groq, OpenRouter, Mistral, custom OpenAI-compatible server).
v0.4: undo history per AI turn, training-data export (jsonl), paste game error (bug button).
v0.5: examples library (www/examples.json from Mojang bedrock-samples, personal use under Minecraft EULA), auto-retry on 429/503, friendly errors.
v0.5.1: daily-quota 429 no longer retried; auto-fallback to other saved provider keys (Groq, OpenRouter, Mistral, Gemini, OpenAI).
v0.6: draw_texture tool - AI draws pixel-art or SVG textures and saves real PNG files into the project (preview shown in chat).
v0.7: example mod "Inside the system" added to the library (mods/inside_the_system/, see INDEX.md) incl. hud_screen/server_form UI, icons and textures (www/examples_assets.json); new copy_example tool copies text or images into the project under a new name.
v0.8: AI can see images - view_image tool, draw_texture auto-shows its result to the AI; settings checkbox for vision-capable models (auto-disabled if the API rejects images).
