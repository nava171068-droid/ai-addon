# Addon AI
Cursor-style app for Minecraft Bedrock addons. Chat with AI, edit BP/RP files, pack .mcaddon.
- App code: www/index.html (AI provider is the `providers` object, swap in your own model later)
- jszip is copied into www/ by `npm run build`
- Paste your API key in Settings inside the app (stored on device only)

v0.2: attach/import files (zip, mcaddon, images, text), web search + fetch_url tools, addon scaffold, share/export via native sheet.
v0.3: multi-provider (Claude, OpenAI, Gemini, Groq, OpenRouter, Mistral, custom OpenAI-compatible server).
v0.4: undo history per AI turn, training-data export (jsonl), paste game error (bug button).
v0.5: examples library (www/examples.json from Mojang bedrock-samples, personal use under Minecraft EULA), auto-retry on 429/503, friendly errors.
