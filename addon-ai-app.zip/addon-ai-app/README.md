# Addon AI
Cursor-style app for Minecraft Bedrock addons. Chat with AI, edit BP/RP files, pack .mcaddon.
- App code: www/index.html (AI provider is the `providers` object, swap in your own model later)
- jszip is copied into www/ by `npm run build`
- Paste your API key in Settings inside the app (stored on device only)
